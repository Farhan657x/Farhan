"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const navigationLinks = [
  { title: "Home", path: "/" },
  { title: "Work", path: "/work" },
  { title: "About", path: "/about" },
  { title: "Contact", path: "/contact" },
];

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const pathname = usePathname();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <>
      <nav className="fixed top-0 left-0 w-full flex justify-between items-center p-6 z-20">
        <Link href="/" className="text-sm font-light tracking-wider text-shayan-gray-light">
          HOME | WORK
        </Link>
        <button
          className="text-sm font-light tracking-wider text-shayan-gray-light cursor-pointer hover:text-shayan-green-light transition-colors duration-300"
          onClick={toggleMenu}
        >
          MENU {isMenuOpen ? "−" : "+"}
        </button>
      </nav>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            className="fixed inset-0 bg-shayan-black z-10 flex items-center justify-center overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="container max-w-7xl mx-auto px-4 text-center">
              <ul className="space-y-8">
                {navigationLinks.map((link, index) => (
                  <motion.li
                    key={link.path}
                    initial={{ y: 40, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -20, opacity: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <Link
                      href={link.path}
                      className={`text-4xl md:text-5xl font-bold tracking-tight hover:text-shayan-green-light transition-colors duration-300 ${
                        pathname === link.path ? "text-shayan-green-light" : "text-shayan-white"
                      }`}
                      onClick={closeMenu}
                    >
                      {link.title}
                    </Link>
                  </motion.li>
                ))}
              </ul>

              <motion.div
                className="mt-16 flex justify-center space-x-8"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.4, delay: 0.5 }}
              >
                <Link
                  href="#"
                  className="text-shayan-gray-light hover:text-shayan-green-light transition-colors duration-300"
                >
                  Instagram
                </Link>
                <Link
                  href="#"
                  className="text-shayan-gray-light hover:text-shayan-green-light transition-colors duration-300"
                >
                  Twitter
                </Link>
                <Link
                  href="#"
                  className="text-shayan-gray-light hover:text-shayan-green-light transition-colors duration-300"
                >
                  LinkedIn
                </Link>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
