"use client";

import { motion } from "framer-motion";
import Link from "next/link";

export default function ContactSection() {
  return (
    <section className="relative w-full py-20 bg-shayan-black text-shayan-white">
      <div className="container max-w-7xl mx-auto px-4">
        <motion.h2
          className="text-4xl md:text-5xl font-bold mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          Get In Touch
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <p className="text-shayan-gray-light leading-relaxed mb-8">
              I'm always open to discussing new projects, creative ideas or opportunities
              to be part of your vision. Feel free to reach out through any of the channels
              below.
            </p>

            <ul className="space-y-4">
              <li>
                <p className="text-shayan-white font-medium">Email</p>
                <Link
                  href="mailto:hello@example.com"
                  className="text-shayan-gray-light hover:text-shayan-green-light transition-colors duration-300"
                >
                  hello@example.com
                </Link>
              </li>
              <li>
                <p className="text-shayan-white font-medium">Social</p>
                <div className="flex space-x-4 mt-2">
                  <Link
                    href="#"
                    className="text-shayan-gray-light hover:text-shayan-green-light transition-colors duration-300"
                  >
                    Instagram
                  </Link>
                  <Link
                    href="#"
                    className="text-shayan-gray-light hover:text-shayan-green-light transition-colors duration-300"
                  >
                    Twitter
                  </Link>
                  <Link
                    href="#"
                    className="text-shayan-gray-light hover:text-shayan-green-light transition-colors duration-300"
                  >
                    LinkedIn
                  </Link>
                </div>
              </li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="bg-shayan-gray-darker p-6 rounded-sm"
          >
            <form className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm text-shayan-gray-light mb-1">Name</label>
                <input
                  type="text"
                  id="name"
                  className="w-full bg-shayan-black border border-shayan-gray-dark rounded-sm px-3 py-2 text-shayan-white focus:outline-none focus:border-shayan-green-light"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm text-shayan-gray-light mb-1">Email</label>
                <input
                  type="email"
                  id="email"
                  className="w-full bg-shayan-black border border-shayan-gray-dark rounded-sm px-3 py-2 text-shayan-white focus:outline-none focus:border-shayan-green-light"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm text-shayan-gray-light mb-1">Message</label>
                <textarea
                  id="message"
                  rows={4}
                  className="w-full bg-shayan-black border border-shayan-gray-dark rounded-sm px-3 py-2 text-shayan-white focus:outline-none focus:border-shayan-green-light"
                />
              </div>
              <button
                type="submit"
                className="px-6 py-2 bg-shayan-green-dark hover:bg-shayan-green-light text-shayan-white transition-colors duration-300 rounded-sm"
              >
                Send Message
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
