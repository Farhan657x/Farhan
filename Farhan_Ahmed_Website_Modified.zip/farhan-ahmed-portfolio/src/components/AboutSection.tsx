"use client";

import { motion } from "framer-motion";

export default function AboutSection() {
  return (
    <section className="relative w-full py-20 bg-shayan-black text-shayan-white">
      <div className="container max-w-7xl mx-auto px-4">
        <motion.h2
          className="text-4xl md:text-5xl font-bold mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          About
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-medium mb-4">Background</h3>
            <p className="text-shayan-gray-light leading-relaxed mb-6">
              I am a multi-disciplinary designer and developer with a passion for creating
              digital experiences that are both functional and visually striking. With a background
              in both design and development, I bring a holistic approach to every project.
            </p>
            <p className="text-shayan-gray-light leading-relaxed">
              My work spans across various domains including UI/UX design, brand identity,
              website development, and interactive installations, with a focus on creating
              memorable user experiences.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-medium mb-4">Skills & Expertise</h3>
            <ul className="grid grid-cols-2 gap-2 text-shayan-gray-light">
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 bg-shayan-green-light rounded-full mr-2" />
                UI/UX Design
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 bg-shayan-green-light rounded-full mr-2" />
                Front-end Development
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 bg-shayan-green-light rounded-full mr-2" />
                Brand Identity
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 bg-shayan-green-light rounded-full mr-2" />
                Interaction Design
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 bg-shayan-green-light rounded-full mr-2" />
                Design Systems
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 bg-shayan-green-light rounded-full mr-2" />
                Web Animation
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 bg-shayan-green-light rounded-full mr-2" />
                Creative Coding
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 bg-shayan-green-light rounded-full mr-2" />
                Visual Design
              </li>
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
