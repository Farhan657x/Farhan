"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";

interface Project {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  link: string;
}

const projects: Project[] = [
  {
    id: "project1",
    title: "Digital Experience",
    description: "UI/UX Design, Development",
    imageUrl: "https://ext.same-assets.com/2999837198/2157646484.png",
    link: "#",
  },
  {
    id: "project2",
    title: "Brand Identity",
    description: "Visual Design, Strategy",
    imageUrl: "https://ext.same-assets.com/2999837198/2132195826.png",
    link: "#",
  },
  {
    id: "project3",
    title: "Mobile Application",
    description: "Interaction Design, Development",
    imageUrl: "https://ext.same-assets.com/2999837198/4129873395.png",
    link: "#",
  },
  {
    id: "project4",
    title: "Design System",
    description: "Component Library, Documentation",
    imageUrl: "https://ext.same-assets.com/2999837198/468360739.png",
    link: "#",
  },
];

export default function WorkSection() {
  return (
    <section className="relative w-full py-20 bg-shayan-black text-shayan-white">
      <div className="container max-w-7xl mx-auto px-4">
        <motion.h2
          className="text-4xl md:text-5xl font-bold mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          Selected Work
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              className="relative group cursor-pointer"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Link href={project.link} className="block">
                <div className="relative aspect-video overflow-hidden bg-shayan-gray-darker rounded-sm">
                  <Image
                    src={project.imageUrl}
                    alt={project.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-shayan-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <div className="mt-4">
                  <h3 className="text-xl font-medium">{project.title}</h3>
                  <p className="text-shayan-gray-light text-sm mt-1">{project.description}</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
